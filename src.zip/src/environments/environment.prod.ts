export const environment = {
  production: true,
  API_URL : 'https://api.github.com'
};
